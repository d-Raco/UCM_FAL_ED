#include<iostream>
#include "Complex.h"
using namespace std;

Complex::Complex() {
	_real = 0;
	_imaginary = 0;
}

Complex::Complex(float real, float imaginary) {
	_real = real;
	_imaginary = imaginary;
}

//Complex Complex::sum(Complex other) {
Complex Complex::operator+(Complex other) {
	Complex result;
	result._real = this->_real + other._real;
	result._imaginary = this->_imaginary + other._imaginary;
	return result;
}

void Complex::print() {
	cout << "(" << _real << ", "<<_imaginary << "i)";
}