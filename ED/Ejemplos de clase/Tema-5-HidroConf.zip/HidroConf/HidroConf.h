/**
  @file confHidro.h

  Implementation of the exercise of the hydrographic confederation.

  Data Structure and Algorithms
  Faculty of Informatics
  Complutense University of Madrid

 (c)Clara Segura, 2015
*/
#ifndef __HIDROCONF_H
#define __HIDROCONF_H

#include <iostream>
using namespace std;

#include "Table.h"

typedef string  River ;
typedef string Reservoir;

class HidroConf {
  public: 
    HidroConf();
    ~HidroConf();
    void addRiver (const River& r);
    void addReservoir (const River& r, const Reservoir& p, int nCap, int nWat);
    void dam (const River& r, const Reservoir& p, int n);
    int getReservoirWater(const River& r, const Reservoir& p);
    int getRiverWater(const River& r);
    void transfer(const River& r1, const Reservoir& p1, const River& r2, 
                   const Reservoir& p2,int n);
  private: 
    struct infoReservoir {
       int capacity;
       int water; //dammed water
    };
    Table<River,Table<Reservoir,infoReservoir> > t_rivers; 
};




#endif // __HIDROCONF_H
