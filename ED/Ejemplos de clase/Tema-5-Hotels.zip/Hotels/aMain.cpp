
#include <iostream>
#include "Agency.h"
#include "ListToString.h"

using namespace std;

int main() {
	Agency a = Agency();
	a.signIn("Juan", "Atocha");
	a.signIn("Juan", "Moncloa");
	a.signIn("Maria", "BonAmi");
	a.signIn("Susana", "Moncloa");
	cout << a.accommodation("Juan") << endl;
	cout << listToStringCommas(a.hotelList()) << endl;
	cout << listToStringCommas(a.guests("Moncloa")) << endl;
	a.signOut("Juan");
	cout << listToStringCommas(a.guests("Moncloa")) << endl;
}


