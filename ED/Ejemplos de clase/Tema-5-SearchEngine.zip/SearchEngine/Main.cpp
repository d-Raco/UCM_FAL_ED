// SearchEngine.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include "SearchEngine.h"
using namespace std;

string listToString(List<int> list) {
	string res;
	List<int>::Iterator it = list.cbegin();
	if (it != list.cend()) {
		res = res + to_string(it.elem());
		it.next();
	}
	while (it != list.cend()) {
		res = res + " " + to_string(it.elem());
		it.next();
	}
	return res;
}

bool solveCase() {
	string op, line;
	int id;
	cin >> op;
	SearchEngine se = SearchEngine();
	bool res = op.compare("end");
	while (op.compare("end")) {
		if (!op.compare("index")) {
			getline(cin, line);
			id = se.index(line);
			cout << id << endl;
		}
		else if (!op.compare("search")) {
			getline(cin, line);
			List<int> docs = se.searchTerms(line);
			cout << listToString(docs)<<endl;
		}
		else if (!op.compare("get")) {
			cin >> id;
			cout << se.getDoc(id) << endl;
		}
		cin >> op;
	}
	return res;
}

/*Simple example */
void simpleExample() {
	SearchEngine se = SearchEngine();
	int id1 = se.index("one cat is on my roof");
	int id2 = se.index("I do not know where my cat went");
	cout << se.getDoc(id1) << endl;
	List<int> docs = se.searchTerms("my cat went");
	List<int>::Iterator it = docs.cbegin();
	while (it != docs.cend()) {
		cout << it.elem() << " ";
		it.next();
	}
}

int main()
{
	while (solveCase()) {
	}
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
