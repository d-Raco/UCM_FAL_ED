#pragma once
template <class T>
class ComplexG
{
private:
	float _real;
	float _imaginary;
public:
	ComplexG();
	ComplexG(T real, T imaginary);
	void print();
	ComplexG<T> operator+(ComplexG<T> other);
};

#include<iostream>
#include "Complex.h"
using namespace std;


template <class T>
ComplexG<T>::ComplexG<T>() {
	_real = 0;
	_imaginary = 0;
}

template <class T>
ComplexG<T>::ComplexG<T>(T real, T imaginary) {
	_real = real;
	_imaginary = imaginary;
}

template <class T>
ComplexG<T> ComplexG<T>::operator+(ComplexG<T> other) {
	ComplexG<T> result;
	result._real = this->_real + other._real;
	result._imaginary = this->_imaginary + other._imaginary;
	return result;
}

template <class T>
void ComplexG<T>::print() {
	cout << "(" << _real << ", " << _imaginary << "i)";
}


