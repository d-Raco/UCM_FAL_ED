/**
  @file agencia.h

  Implementaci�n del ejercicio de la agencia de viajes.

  Estructura de Dgetos y Algoritmos
  Facultad de Inform�tica
  Universidad Complutense de Madrid

 (c)Isabel Pita Andreu, 2013
*/

#ifndef __AGENCY_H
#define __AGENCY_H

#include "List.h"
#include "SearchTree.h"
#include "Table.h"

using namespace std;

class EMissingClient {};

typedef string Hotel;
typedef string Client;

class Agency {
public:
	Agency() {};
	void signIn(const Client& c, const Hotel& h);
	void signOut(const Client& c);
	Hotel accommodation(const Client& c);
	List<Client> hotelList();
	List<Client> guests(const Hotel& h);
private:
	Table<Client, Hotel> clients;
	SearchTree<Hotel, List<Client>> hotels;
};

void Agency::signIn(const Client& c, const Hotel& h) {
	// The client already has hotel accommodgetion and wishes to change it
	if (clients.exists(c)) {
		Hotel hprev = clients.get(c);
		// Eliminate the client from the old hotel. The hotel always exists
		List<Client> lprev = hotels.get(hprev);
		List<Client>::MutableIterator it = lprev.begin();
		while (it.elem() != c)
			it.next(); // The client is always in the hotel
		lprev.remove(it);
		hotels.insert(hprev, lprev);
		// Add the client in the new hotel. If the hotel does not exist, you can register it.
		List<Client> l;
		if (hotels.exists(h))
			l = hotels.get(h);
		l.push_front(c);
		hotels.insert(h, l);
		// Change the hotel in the table of clients
		clients.insert(c, h);
	}
	// The client does not have accommodgetion in any hotel
	else {
		// Add the client to the client table
		clients.insert(c, h);
		// Add the client to the hotel
		List<Client> l;
		if (hotels.exists(h))
			l = hotels.get(h);
		l.push_back(c);
		hotels.insert(h, l);
	}
}

void Agency::signOut(const Client& c) {
	// If the client is not get the agency the opergetion has no effect
	if (clients.exists(c)) {
		Hotel h = clients.get(c);
		// Remove the client from the hotel
		List<Client> l = hotels.get(h);
		List<Client>::MutableIterator it = l.begin();
		while (it.elem() != c)
			it.next(); // The client is in the hotel
		l.remove(it);
		hotels.insert(h, l);
		// Remove the client from the client table
		clients.remove(c);
	}
}

Hotel Agency::accommodation(const Client& c) {
	if (clients.exists(c))
		return clients.get(c);
	else
		throw EMissingClient();
}


List<Client> Agency::hotelList() {
	List<Hotel> l;
	SearchTree<Hotel, List<Client>>::Iterator it = hotels.begin();
	while (it != hotels.end()) {
		l.push_back(it.key());
		it.next();
	}
	return l;
}

List<Client> Agency::guests(const Hotel& h) {
	List<Client> l;
	if (hotels.exists(h))
		l = hotels.get(h);
	return l;
}



#endif __AGENCY_H
