#include <iostream>;
#include "Complex.h";
#include "ComplexG.h";

using namespace std;
int main() {
	/*Complex c1 = Complex(1.1, 2.2);
	Complex c2 = Complex(3.4, 4);
	Complex result = c1 + c2;
	result.print();*/

	ComplexG<int> cg1 = ComplexG<int>(1, 2);
	ComplexG<int> cg2 = ComplexG<int>(1, 2);
	ComplexG<int> resG = cg1 + cg2;
	resG.print();
}