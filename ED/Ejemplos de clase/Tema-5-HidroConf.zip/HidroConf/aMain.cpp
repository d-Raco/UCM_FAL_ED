#include <iostream>
#include "HidroConf.h"
using namespace std;
int main() {
	HidroConf h = HidroConf();
	River g = "Guadalquivir";
	Reservoir g1 = "Santana";
	Reservoir g2 = "DonAna";
	River t = "Tajo";
	Reservoir t1 = "Minuesa";
	h.addRiver(g);
	h.addRiver(t);
	h.addReservoir(g, g1, 100, 50);
	h.dam(g, g1, 25);
	h.addReservoir(g, g2, 110, 60);
	h.addReservoir(t, t1, 150, 200);
	h.transfer(t, t1, g, g1, 10);
	cout << "The resevoir "<<g1<<" of river "<<g<<" has "
		<< h.getReservoirWater(g, g1)<< " m3 of water"<<endl;
	cout << "The reservoirs of river " << g << " has "
		<< h.getRiverWater(g) << " m3 of water"<<endl;

}