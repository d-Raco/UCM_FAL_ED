#pragma once
class Complex
{
private:
	float _real;
	float _imaginary;
public:
	Complex();
	Complex(float real, float imaginary);
	void print();
	//Complex sum(Complex other);
	Complex operator+(Complex other);
};

