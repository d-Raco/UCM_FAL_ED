/**
  @file confHidro.h

  Implementation of the Hydrographic Confederation exercise.

  Data Structure and Algorithms
  Faculty of Informatics
  Complutense University of Madrid

 (c)Clara Segura, 2015
*/
#include "HidroConf.h"




HidroConf::HidroConf(){
  t_rivers = Table<River,Table<Reservoir,infoReservoir> >(); 
}

HidroConf::~HidroConf() {
}



void HidroConf::addRiver (const River& r){
    // If the river exists, the associated value should not change
    if (!t_rivers.exists(r)) 
          {t_rivers.insert(r, Table<Reservoir,infoReservoir>());}
}


void HidroConf::addReservoir (const River& r, const Reservoir& p,
                                         int nCap, int nWat){
    if (t_rivers.exists(r) && !t_rivers.get(r).exists(p)) {
            // creates the Reservoir information
            infoReservoir i;
            i.capacity = nCap;
            if (nWat < nCap) 
				i.water = nWat;
            else 
				i.water = nCap;
            // add information to river
            t_rivers.get(r).insert(p,i);
        }
}


void HidroConf::dam (const River& r, const Reservoir& p,
                                       int n){
    if (t_rivers.exists(r) && t_rivers.get(r).exists(p)) {
            // Add water Reservoir
            t_rivers.get(r).get(p).water += n;
            if (t_rivers.get(r).get(p).water > t_rivers.get(r).get(p).capacity) 
                t_rivers.get(r).get(p).water = t_rivers.get(r).get(p).capacity;
          }
}


int HidroConf::getReservoirWater(const River& r,
                                              const Reservoir& p){
    int n = -1;
    if (t_rivers.exists(r) && t_rivers.get(r).exists(p)) {
        n=t_rivers.get(r).get(p).water;
        }
    return n;
}


int HidroConf::getRiverWater(const River& r){
    int n = 0;
    if (t_rivers.exists(r)) {
        Table<Reservoir,infoReservoir>::Iterator it=t_rivers.get(r).begin();
        while (it != t_rivers.get(r).end()) {
            infoReservoir i = it.value();
            n += i.water;
            it.next();
        }
    }
    return n;
}


void HidroConf::
  transfer(const River& r1, const Reservoir& p1, 
            const River& r2, const Reservoir& p2,int n){
    if (t_rivers.exists(r1) && t_rivers.exists(r2) &&
		t_rivers.get(r1).exists(p1) && t_rivers.get(r2).exists(p2)&&
		t_rivers.get(r1).get(p1).water >= n &&
        t_rivers.get(r2).get(p2).water + n <= t_rivers.get(r2).get(p2).capacity) {
			t_rivers.get(r1).get(p1).water -= n;
            t_rivers.get(r2).get(p2).water += n;
       }
}




