// SearchTree.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "SearchTree.h"
#include <string>
using namespace std;

void basicExample() {
	SearchTree<int, int> st = SearchTree<int, int>();
	st.insert(5, 11);
	st.insert(3, 12);
	st.insert(7, 13);
	st.insert(1, 14);
	st.remove(7);
	if (!st.empty()) {
		SearchTree<int, int> st2 = st;
		cout << "Key of 1 is " << st2.get(1) << endl;
		if (!st.exists(10))
			cout << "10 does not exist" << endl;
		SearchTree<int, int>::Iterator it = st.begin();
		while (it != st.end()) {
			cout << "Key: " << it.key() << ";    Value: " << it.value() << endl;
			it.next();
		}
	}
}

void pointersExample() {
	SearchTree<int, string>* pst = new SearchTree<int, string>();
	pst->insert(5, "a");
	pst->insert(3, "b");
	pst->insert(7, "c");
	pst->insert(3, "g"); // Example of Replacement
	pst->insert(1, "d");
	pst->remove(7);
	SearchTree<int, string>::Iterator itc = pst->begin();
	while (itc != pst->end()) {
		cout << "Key: " << itc.key() << ";    Value: " << itc.value() << endl;
		itc.next();
	}
	delete pst;
}

void stringKeysExample() {
	SearchTree<string, int> st3 = SearchTree<string, int>();
	st3.insert("Juan", 5);
	st3.insert("Maria", 7);
	st3.insert("Abel", 2);
	SearchTree<string, int>::Iterator it3 = st3.begin();
	while (it3 != st3.end()) {
		cout << "Key: " << it3.key() << ";    Value: " << it3.value() << endl;
		it3.next();
	}
}


int main()
{
	basicExample();
	pointersExample();
	stringKeysExample();
}

