// EDp7.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Bintree.h"
#include "List.h"
using namespace std;
void example1();
Bintree<int> readBintree();
void showBintree(Bintree<int> t);

/* Generalization of the latter function.
The output parameter "descen" will contian the number of nodes of the tree
(including root and all the other nodes). */
int oddDescen(Bintree<int> t, int& descen) {
	int res;
	// Base case
	if (t.empty()) {
		descen = 0;
		res = 0;
	}
	// Recursive case
	else {
		int descenLf, descenRg, resLf, resRg;
		resLf = oddDescen(t.leftChild(), descenLf);
		resRg = oddDescen(t.rightChild(), descenRg);
		res = resLf + resRg;
		if ((descenLf + descenRg) % 2 == 1) {
			res++;
		}
		descen = descenLf + descenRg + 1;
	}
	return res;
}

/*It calculates the number of nodes that have an odd number of descendents*/
int oddDescen(Bintree<int> t) {
	int descen;
	return oddDescen(t, descen);
}

/* It calculates the number of nodes that have a greater sum in the descendents
than in the antecesslors. 
The input param "sumAntec" has the sum of antecessors. 
The output param "sumDecen" calculates the sum of descendents.
*/
int greaterDescen(Bintree<int> t, int sumAntec, int &sumDescen) {
	int res;
	// Base case
	if (t.empty()) {
		sumDescen = 0;
		res = 0;
	}
	// Recursive case
	else{
		int sumAntecRec = sumAntec + t.root();
		int resLf, resRg, sumDescenLf, sumDescenRg;
		resLf = greaterDescen(t.leftChild(), sumAntecRec, sumDescenLf);
		resRg = greaterDescen(t.rightChild(), sumAntecRec, sumDescenRg);
		res = resLf + resRg;
		if ((sumDescenLf + sumDescenRg) > sumAntec) {
			res++;
		}
		sumDescen = sumDescenLf + sumDescenRg + t.root();
	}
	return res;
}

/* It calculates the number of nodes that have a greater sum in the descendents
than in the antecesslors. */
int greaterDescen(Bintree<int> t) {
	int sumAntec = 0;
	int sumDescen;
	return greaterDescen(t, sumAntec, sumDescen);
}

/* Try this example by typing in the console the following tree:
(([1] 7 [3]) 4 [9])
*/
int main()
{
	Bintree<int> t = readBintree();
	cout << "Number of nodes for Odd Desendents: " << oddDescen(t)<<endl;
	cout << "Number of nodes for Greater sum of Descendents: " << greaterDescen(t);
	//showBintree(t);
}

// It reads a binary tree of integers from the standard input
Bintree<int> readBintree() {
	char c;
	cin >> c;
	switch (c) {
	case '#': return Bintree<int>();
	case '[': {
		int raiz;
		cin >> raiz;
		cin >> c;
		return Bintree<int>(raiz);
	}
	case '(': {
		Bintree<int> left = readBintree();
		int root;
		cin >> root;
		Bintree<int> right = readBintree();
		cin >> c;
		return Bintree<int>(left, root, right);
	}
	default:
		return Bintree<int>();
	}
}

// It shows one tree using in-order tour
void showBintree(Bintree<int> t) {
	List<int> l = t.inorder();
	List<int>::Iterator it = l.cbegin();
	while (it != l.cend()) {
		cout << it.elem() << " ";
		it.next();
	}
}

// Example of building and showing one tree
void example1() {
	Bintree<int> t1 = Bintree<int>(Bintree<int>(1), 7, Bintree<int>(3));
	Bintree<int> t = Bintree<int>(t1, 4, Bintree<int>(9));
	showBintree(t);
}

