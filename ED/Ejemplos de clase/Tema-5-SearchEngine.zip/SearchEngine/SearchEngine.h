#pragma once
#include <string>
#include <sstream>
#include "Table.h"
#include "List.h"

using namespace std;

/* Implements a Search Engine of documents*/
class SearchEngine {
public:
	/* Builder */
	SearchEngine() {
		docs = Table<int, string>();
		terms = Table<string, List<int>>();
		numDocs = 0;
	}
	/* It stores the whole documen and index all the words
	inside the document. It retuns an identifier of this
	document*/
	int index(string doc) {
		// Storing the complete document
		int id = numDocs;
		docs.insert(id, doc);
		numDocs++;
		// Indexing all the terms
		istringstream iss(doc);
		string term;
		while (iss >> term) {
			if (!terms.exists(term))
				terms.insert(term, List<int>());
			terms.get(term).push_back(id);

		}
		return id;
	}
	/* Returns the document of a given identifier */
	string getDoc(int id) {
		return docs.get(id);
	}
	/* It returns all the documents that contain all the words
	in the phrase of the parameter */
	List<int> searchTerms(string phrase) {
		istringstream iss(phrase);
		string firstTerm, term;
		iss >> firstTerm;
		List <int> res = searchTerm(firstTerm);
		while (iss >> term && !res.empty()) {
			res = intersection(res, searchTerm(term));
		}
		return res;
	}

	

private:
	// Table to rapid access of content of each document
	Table<int, string> docs;
	/* Table to rapid access of all the documents that contain 
	 each term. Each list of documents is always sorted as 
	 the documents are indexed with increasing IDs */
	Table<string, List<int>> terms;
	// The number of documents to assign next index
	int numDocs;

	/* It returns the intersection of two ordered lists as a list */
	List <int> intersection(List<int> l1, List<int> l2) {
		List<int>::Iterator it1 = l1.cbegin();
		List<int>::Iterator it2 = l2.cbegin();
		List<int> res = List<int>();
		while (it1 != l1.cend() && it2 != l2.cend()) {
			if (it1.elem() == it2.elem()) {
				res.push_back(it1.elem());
				it1.next();
				it2.next();
			}
			else if (it1.elem() < it2.elem()) {
				it1.next();
			}
			else {
				it2.next();
			}
		}
		return res;
	}

	/* It returns a list of all the documents of a givent term*/
	List<int> searchTerm(string term) {
		List<int> res;
		if (!terms.exists(term)) {
			res = List<int>();
		}
		else {
			//while (iss>>term){}
			res = terms.get(term);
		}
		return res;
	}
};